package com.example.android.udacityplay;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ArtistAdapter extends ArrayAdapter<ArtistDec> {

    public ArtistAdapter(Activity context, ArrayList<ArtistDec> words) {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, words);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {// Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.artist_layout,parent, false);
        }

        // Get the {@link AndroidFlavor} object located at this position in the list
        ArtistDec currentWord = getItem(position);

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView AlbumName = (TextView) listItemView.findViewById(R.id.tvAlbum);
        // Get the version name from the current AndroidFlavor object and
        // set this text on the name TextView
        AlbumName.setText(currentWord.getArtistName());

        // Find the TextView in the list_item.xml layout with the ID version_number
        TextView ArtistName = (TextView) listItemView.findViewById(R.id.tvArtist);
        // Get the version number from the current AndroidFlavor object and
        // set this text on the number TextView
        ArtistName.setText(currentWord.getAlbumName());

        ImageView img = (ImageView) listItemView.findViewById(R.id.ivAlbum);
        img.setImageResource(currentWord.getivAlbum());

        // Return the whole list item layout (containing 2 TextViews and an ImageView)
        // so that it can be shown in the ListView
        return listItemView;
    }
}
