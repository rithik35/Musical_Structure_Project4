package com.example.android.udacityplay;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.nowPlayingCard).setOnClickListener(this);
        findViewById(R.id.allTracksCard).setOnClickListener(this);
        findViewById(R.id.artistCard).setOnClickListener(this);
        findViewById(R.id.albumsCard).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.nowPlayingCard:
                nowPlaying();
                break;
            case R.id.allTracksCard:
                allTracks();
                break;
            case R.id.artistCard:
                artist();
                break;
            case R.id.albumsCard:
                album();
                break;
            default:
             break;
        }
    }


    public void nowPlaying() {
        Intent intent = new Intent(MainActivity.this, PlayerDisplay.class);
        startActivity(intent);
        }

    public void album() {
        Intent intent=new Intent(MainActivity.this,Albums.class);
        startActivity(intent);
        }

    public void artist() {
        Intent intent=new Intent(MainActivity.this,Artist.class);
        startActivity(intent);
        }

    public void allTracks() {
        Intent intent=new Intent(MainActivity.this,all_tracks.class);
        startActivity(intent);
        }

}
