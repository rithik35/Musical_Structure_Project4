package com.example.android.udacityplay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.GridView;

import java.util.ArrayList;

public class Albums extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_albums);
        ArrayList<albumDeclaration> albums = new ArrayList<albumDeclaration>();
        albums.add(new albumDeclaration("album1", "artist1", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album2", "artist2", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album3", "artist3", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album4", "artist4", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album5", "artist5", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album6", "artist6", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album7", "artist7", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album8", "artist8", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album9", "artist9", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album10", "artist10", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album11", "artist11", R.drawable.ic_person_black_24dp));
        albums.add(new albumDeclaration("album12", "artist12", R.drawable.ic_person_black_24dp));

        AlbumAdapter adapter = new AlbumAdapter(this, albums);
        GridView gridView = findViewById(R.id.gridViewAlbum);
        gridView.setAdapter(adapter);

        }
}
