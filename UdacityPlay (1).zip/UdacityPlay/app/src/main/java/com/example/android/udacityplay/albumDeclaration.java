package com.example.android.udacityplay;

public class albumDeclaration {
    private String Album;
    private String Artist;
    private int Img_res;

    public albumDeclaration(String Album, String Artist, int Img_res) {
        this.Album = Album;
        this.Artist = Artist;
        this.Img_res = Img_res;
    }

    public String getAlbum() {
        return Album;
    }

    public String getArtist() {
        return Artist;
    }

    public int getImg_res() {

        return Img_res;
    }
}
