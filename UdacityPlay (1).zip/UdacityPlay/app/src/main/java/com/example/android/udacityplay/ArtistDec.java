package com.example.android.udacityplay;

public class ArtistDec {
    private String artistName;
    private String albumName;
    private int ivAlbum;

    public ArtistDec(String artistName, String albumName, int ivAlbum) {
        this.artistName = artistName;
        this.albumName = albumName;
        this.ivAlbum = ivAlbum;
    }

    public String getArtistName() {
        return artistName;
    }

    public String getAlbumName() {
        return albumName;
    }

    public int getivAlbum() { return ivAlbum; }

}
