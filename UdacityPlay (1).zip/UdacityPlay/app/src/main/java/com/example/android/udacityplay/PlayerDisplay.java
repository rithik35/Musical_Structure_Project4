package com.example.android.udacityplay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class PlayerDisplay extends AppCompatActivity {

    boolean playing=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_display);
    }

    public void Resume(View view) {
        playing = !playing;
        ((ImageView) findViewById(R.id.ResumeView)).setImageResource(playing ? R.drawable.play : R.drawable.pause);

    }
    }

