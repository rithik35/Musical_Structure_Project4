package com.example.android.udacityplay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ListView;

import java.util.ArrayList;

public class all_tracks extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_tracks);

        ArrayList<Track> tracks = new ArrayList<Track>();
        tracks.add(new Track("someTitle", "Artist1", "album1", R.drawable.tracks));
        tracks.add(new Track(" someTitle", "Artist1 ", "album1", R.drawable.tracks));
        tracks.add(new Track(" someTitle", "Artist1 ", "album1", R.drawable.tracks));
        tracks.add(new Track("someTitle", "Artist1", "album1", R.drawable.tracks));
        tracks.add(new Track(" someTitle", "Artist1", "album1", R.drawable.tracks));
        tracks.add(new Track("someTitle ", "Artist1", "album1", R.drawable.tracks));

        TracksAdapter adapter = new TracksAdapter(this, tracks);

        ListView listView = (ListView) findViewById(R.id.listViewTracks);

        listView.setAdapter(adapter);

    }
}
