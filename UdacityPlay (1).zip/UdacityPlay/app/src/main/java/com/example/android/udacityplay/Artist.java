package com.example.android.udacityplay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Artist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist);


        ArrayList<ArtistDec> artists= new ArrayList<ArtistDec>();
        artists.add(new ArtistDec("Artist1", "album1", R.drawable.ed_circle));
        artists.add(new ArtistDec("Artist1", "album1", R.drawable.ed_circle));
        artists.add(new ArtistDec("Artist1", "album1", R.drawable.ed_circle));
        artists.add(new ArtistDec("Artist1", "album1", R.drawable.ed_circle));
        artists.add(new ArtistDec("Artist1", "album1", R.drawable.ed_circle));
        artists.add(new ArtistDec("Artist1", "album1", R.drawable.ed_circle));
        artists.add(new ArtistDec("Artist1", "album1", R.drawable.ed_circle));

        ArtistAdapter adapter = new ArtistAdapter(this, artists);

        ListView listView = (ListView) findViewById(R.id.listViewArtist);

        listView.setAdapter(adapter);

    }
}
